# LIGitHubPR
Firefox Extension to provide a file tree on PR files view

## Submitting addons on Mozilla Add-ons site

see official doc: https://developer.mozilla.org/fr/Add-ons/Distribution/Submitting_an_add-on

### Quick way

./generateReleaseArtifact.sh

Upload generated file to unlisted extension submitting page (not available on addons.mozilla.org)
https://addons.mozilla.org/en-US/developers/addon/submit/upload-unlisted

Sign add-on and download generated `.xpi` file.
